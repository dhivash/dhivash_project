@echo off
title EduTrack Pro - Launcher
echo ========================================================
echo        EduTrack Pro - Student Management System
echo         Full-Stack CRUD Web Application Platform
echo ========================================================
echo.
echo [1/3] Checking environment...
set "PATH=C:\Users\ASus\AppData\Local\Programs\Python\Python312;C:\Users\ASus\AppData\Local\Programs\Python\Python312\Scripts;%LOCALAPPDATA%\Microsoft\WinGet\Packages\OpenJS.NodeJS.LTS_Microsoft.Winget.Source_8wekyb3d8bbwe\node-v24.19.0-win-x64;%LOCALAPPDATA%\Microsoft\WinGet\Packages\Git.MinGit_Microsoft.Winget.Source_8wekyb3d8bbwe\cmd;%PATH%"

echo [2/3] Starting Django REST Backend on http://127.0.0.1:8000 ...
start "EduTrack Backend" cmd /k "cd /d %~dp0backend && python manage.py runserver 127.0.0.1:8000"

echo [3/3] Opening Application in Default Web Browser...
timeout /t 3 /nobreak >nul
start http://127.0.0.1:8000

echo.
echo ========================================================
echo Server is running!
echo URL: http://127.0.0.1:8000
echo API Root: http://127.0.0.1:8000/api/students/
echo Admin Panel: http://127.0.0.1:8000/admin/
echo.
echo Press any key to exit this launcher window (server stays running).
echo ========================================================
pause >nul
