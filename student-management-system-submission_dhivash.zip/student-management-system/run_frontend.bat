@echo off
title EduTrack Pro - React Vite Frontend
set "PATH=%LOCALAPPDATA%\Microsoft\WinGet\Packages\OpenJS.NodeJS.LTS_Microsoft.Winget.Source_8wekyb3d8bbwe\node-v24.19.0-win-x64;%PATH%"
cd /d %~dp0frontend
echo Installing dependencies if required and launching Vite dev server...
call npm.cmd install
call npm.cmd run dev
pause
