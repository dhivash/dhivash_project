﻿from django.contrib import admin
from .models import Student

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = (
        'roll_number',
        'first_name',
        'last_name',
        'department',
        'semester',
        'gpa',
        'status',
        'enrollment_date'
    )
    list_filter = ('department', 'status', 'semester')
    search_fields = ('roll_number', 'first_name', 'last_name', 'email')
    ordering = ('-created_at',)
    readonly_fields = ('created_at', 'updated_at')
