﻿from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import StudentViewSet, portal_view

router = DefaultRouter()
router.register(r'students', StudentViewSet, basename='student')

urlpatterns = [
    path('api/', include(router.urls)),
    path('', portal_view, name='portal'),
]
