﻿from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from .models import Student

class StudentAPITestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.student = Student.objects.create(
            roll_number="TEST-2024-001",
            first_name="John",
            last_name="Doe",
            email="john.doe@test.edu",
            phone="+1234567890",
            department="Computer Science",
            semester=4,
            gpa=3.75,
            status="Active",
            address="123 Campus Way"
        )
        self.valid_payload = {
            "roll_number": "TEST-2024-002",
            "first_name": "Jane",
            "last_name": "Smith",
            "email": "jane.smith@test.edu",
            "phone": "+1987654321",
            "department": "Information Technology",
            "semester": 3,
            "gpa": 3.90,
            "status": "Active",
            "address": "456 University Ave"
        }

    # --- CREATE TESTS (POST) ---
    def test_create_student_success(self):
        response = self.client.post('/api/students/', self.valid_payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['roll_number'], "TEST-2024-002")
        self.assertEqual(response.data['first_name'], "Jane")
        self.assertTrue(Student.objects.filter(roll_number="TEST-2024-002").exists())

    def test_create_student_duplicate_roll_number(self):
        payload = self.valid_payload.copy()
        payload['roll_number'] = "TEST-2024-001" # Already exists
        response = self.client.post('/api/students/', payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('roll_number', response.data)

    def test_create_student_duplicate_email(self):
        payload = self.valid_payload.copy()
        payload['email'] = "john.doe@test.edu" # Already exists
        response = self.client.post('/api/students/', payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('email', response.data)

    def test_create_student_invalid_email_format(self):
        payload = self.valid_payload.copy()
        payload['email'] = "invalid-email-address"
        response = self.client.post('/api/students/', payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('email', response.data)

    def test_create_student_invalid_gpa_out_of_range(self):
        payload = self.valid_payload.copy()
        payload['gpa'] = 4.50 # Max is 4.0
        response = self.client.post('/api/students/', payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('gpa', response.data)

        payload['gpa'] = -0.50 # Min is 0.0
        response = self.client.post('/api/students/', payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('gpa', response.data)

    def test_create_student_invalid_semester(self):
        payload = self.valid_payload.copy()
        payload['semester'] = 9 # Must be 1 to 8
        response = self.client.post('/api/students/', payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('semester', response.data)

    def test_create_student_missing_required_fields(self):
        incomplete_payload = {"first_name": "Incomplete"}
        response = self.client.post('/api/students/', incomplete_payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('roll_number', response.data)
        self.assertIn('email', response.data)

    # --- READ TESTS (GET) ---
    def test_list_students(self):
        response = self.client.get('/api/students/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # DRF paginated response contains 'results'
        results = response.data.get('results', response.data)
        self.assertGreaterEqual(len(results), 1)

    def test_retrieve_single_student_success(self):
        response = self.client.get(f'/api/students/{self.student.id}/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['roll_number'], "TEST-2024-001")
        self.assertEqual(response.data['email'], "john.doe@test.edu")

    def test_retrieve_student_not_found(self):
        response = self.client.get('/api/students/999999/')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    # --- UPDATE TESTS (PUT / PATCH) ---
    def test_full_update_student_put(self):
        updated_payload = {
            "roll_number": "TEST-2024-001",
            "first_name": "Johnny",
            "last_name": "Doe Updated",
            "email": "johnny.updated@test.edu",
            "phone": "+1234567890",
            "department": "Computer Science",
            "semester": 5,
            "gpa": 3.82,
            "status": "Active",
            "address": "999 Tech Park"
        }
        response = self.client.put(f'/api/students/{self.student.id}/', updated_payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.student.refresh_from_db()
        self.assertEqual(self.student.first_name, "Johnny")
        self.assertEqual(self.student.email, "johnny.updated@test.edu")
        self.assertEqual(float(self.student.gpa), 3.82)

    def test_partial_update_student_patch(self):
        patch_payload = {"gpa": 3.95, "status": "Graduated"}
        response = self.client.patch(f'/api/students/{self.student.id}/', patch_payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.student.refresh_from_db()
        self.assertEqual(float(self.student.gpa), 3.95)
        self.assertEqual(self.student.status, "Graduated")

    # --- DELETE TESTS (DELETE) ---
    def test_delete_student_success(self):
        response = self.client.delete(f'/api/students/{self.student.id}/')
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(Student.objects.filter(id=self.student.id).exists())

    def test_delete_student_not_found(self):
        response = self.client.delete('/api/students/999999/')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    # --- SEARCH & FILTER TESTS ---
    def test_search_student_by_name(self):
        response = self.client.get('/api/students/?search=John')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data.get('results', response.data)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['first_name'], "John")

    def test_filter_student_by_department(self):
        response = self.client.get('/api/students/?department=Computer+Science')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data.get('results', response.data)
        self.assertTrue(all(s['department'] == 'Computer Science' for s in results))

    # --- STATISTICS ENDPOINT TEST ---
    def test_statistics_endpoint(self):
        response = self.client.get('/api/students/statistics/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('total_students', response.data)
        self.assertIn('active_students', response.data)
        self.assertIn('average_gpa', response.data)
        self.assertIn('departments', response.data)
        self.assertGreaterEqual(response.data['total_students'], 1)
