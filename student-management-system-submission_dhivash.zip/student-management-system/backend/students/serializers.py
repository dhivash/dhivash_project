﻿import re
from rest_framework import serializers
from .models import Student

class StudentSerializer(serializers.ModelSerializer):
    full_name = serializers.ReadOnlyField()

    class Meta:
        model = Student
        fields = [
            'id',
            'roll_number',
            'first_name',
            'last_name',
            'full_name',
            'email',
            'phone',
            'department',
            'semester',
            'gpa',
            'enrollment_date',
            'status',
            'address',
            'created_at',
            'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate_roll_number(self, value):
        val = value.strip().upper()
        if not val:
            raise serializers.ValidationError("Roll number cannot be empty.")
        # Check uniqueness during create or update
        instance = getattr(self, 'instance', None)
        qs = Student.objects.filter(roll_number__iexact=val)
        if instance:
            qs = qs.exclude(pk=instance.pk)
        if qs.exists():
            raise serializers.ValidationError(f"Student with roll number '{val}' already exists.")
        return val

    def validate_first_name(self, value):
        val = value.strip()
        if not val:
            raise serializers.ValidationError("First name is required.")
        if len(val) < 2:
            raise serializers.ValidationError("First name must be at least 2 characters long.")
        return val

    def validate_last_name(self, value):
        val = value.strip()
        if not val:
            raise serializers.ValidationError("Last name is required.")
        return val

    def validate_email(self, value):
        val = value.strip().lower()
        if not val:
            raise serializers.ValidationError("Email address is required.")
        instance = getattr(self, 'instance', None)
        qs = Student.objects.filter(email__iexact=val)
        if instance:
            qs = qs.exclude(pk=instance.pk)
        if qs.exists():
            raise serializers.ValidationError(f"A student with email '{val}' already exists.")
        return val

    def validate_phone(self, value):
        val = value.strip()
        if not val:
            raise serializers.ValidationError("Phone number is required.")
        # Basic validation for digits and phone formatting characters
        cleaned = re.sub(r'[\s\-\(\)\+]', '', val)
        if not cleaned.isdigit() or len(cleaned) < 7 or len(cleaned) > 15:
            raise serializers.ValidationError("Please provide a valid phone number (7 to 15 digits).")
        return val

    def validate_gpa(self, value):
        try:
            val = float(value)
        except (ValueError, TypeError):
            raise serializers.ValidationError("GPA must be a valid decimal number.")
        if val < 0.0 or val > 4.0:
            raise serializers.ValidationError("GPA must be between 0.00 and 4.00.")
        return round(val, 2)

    def validate_semester(self, value):
        if value < 1 or value > 8:
            raise serializers.ValidationError("Semester must be between 1 and 8.")
        return value
