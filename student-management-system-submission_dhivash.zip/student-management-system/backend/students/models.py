﻿from decimal import Decimal
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone

class Student(models.Model):
    DEPARTMENT_CHOICES = [
        ('Computer Science', 'Computer Science & Engineering'),
        ('Information Technology', 'Information Technology'),
        ('Electronics', 'Electronics & Communication'),
        ('Mechanical', 'Mechanical Engineering'),
        ('Civil', 'Civil Engineering'),
        ('Data Science', 'Data Science & Artificial Intelligence'),
    ]

    STATUS_CHOICES = [
        ('Active', 'Active'),
        ('Inactive', 'Inactive'),
        ('Graduated', 'Graduated'),
        ('Suspended', 'Suspended'),
    ]

    roll_number = models.CharField(
        max_length=20,
        unique=True,
        db_index=True,
        help_text="Unique Student Roll Number (e.g. STU-2026-001)"
    )
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(max_length=100, unique=True)
    phone = models.CharField(max_length=20)
    department = models.CharField(max_length=50, choices=DEPARTMENT_CHOICES, default='Computer Science')
    semester = models.IntegerField(
        default=1,
        validators=[MinValueValidator(1), MaxValueValidator(8)],
        help_text="Current Semester (1 to 8)"
    )
    gpa = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=Decimal('3.50'),
        validators=[MinValueValidator(Decimal('0.00')), MaxValueValidator(Decimal('4.00'))],
        help_text="Grade Point Average on 4.00 scale"
    )
    enrollment_date = models.DateField(default=timezone.localdate)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Active')
    address = models.TextField(blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Student'
        verbose_name_plural = 'Students'

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"

    def __str__(self):
        return f"{self.roll_number} - {self.full_name}"
