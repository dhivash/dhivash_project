﻿from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db.models import Avg, Count
from django.shortcuts import render
from .models import Student
from .serializers import StudentSerializer

class StudentViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows full CRUD operations on Student records.
    Provides search, filtering, sorting, pagination, and aggregate statistics.
    """
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['roll_number', 'first_name', 'last_name', 'email', 'department']
    ordering_fields = ['created_at', 'gpa', 'roll_number', 'semester', 'first_name']
    ordering = ['-created_at']

    def get_queryset(self):
        queryset = super().get_queryset()
        department = self.request.query_params.get('department', None)
        status_param = self.request.query_params.get('status', None)

        if department and department != 'All':
            queryset = queryset.filter(department__iexact=department)
        if status_param and status_param != 'All':
            queryset = queryset.filter(status__iexact=status_param)

        return queryset

    @action(detail=False, methods=['get'], url_path='statistics')
    def statistics(self, request):
        """
        Provides aggregate analytics for the student dashboard.
        """
        total = Student.objects.count()
        active = Student.objects.filter(status='Active').count()
        graduated = Student.objects.filter(status='Graduated').count()
        inactive = Student.objects.filter(status='Inactive').count()
        suspended = Student.objects.filter(status='Suspended').count()
        avg_gpa = Student.objects.aggregate(avg=Avg('gpa'))['avg'] or 0.0
        honor_roll = Student.objects.filter(gpa__gte=3.50).count()

        # Department distribution
        dept_counts = (
            Student.objects.values('department')
            .annotate(count=Count('id'))
            .order_by('-count')
        )

        return Response({
            'total_students': total,
            'active_students': active,
            'graduated_students': graduated,
            'inactive_students': inactive,
            'suspended_students': suspended,
            'average_gpa': round(float(avg_gpa), 2),
            'honor_roll_students': honor_roll,
            'departments': list(dept_counts),
        }, status=status.HTTP_200_OK)


def portal_view(request):
    """
    Serves the integrated modern single-page dashboard application.
    """
    return render(request, 'index.html')
