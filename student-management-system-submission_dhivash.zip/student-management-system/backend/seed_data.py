﻿import os
import sys
import django
from datetime import date

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edutrack.settings')
django.setup()

from students.models import Student

sample_students = [
    {
        "roll_number": "STU-2024-001",
        "first_name": "Aarav",
        "last_name": "Sharma",
        "email": "aarav.sharma@university.edu",
        "phone": "+91-9876543210",
        "department": "Computer Science",
        "semester": 6,
        "gpa": 3.92,
        "enrollment_date": date(2023, 8, 1),
        "status": "Active",
        "address": "42 Tech Boulevard, Silicon Wing, Bangalore"
    },
    {
        "roll_number": "STU-2024-002",
        "first_name": "Priya",
        "last_name": "Patel",
        "email": "priya.patel@university.edu",
        "phone": "+91-9876543211",
        "department": "Information Technology",
        "semester": 4,
        "gpa": 3.85,
        "enrollment_date": date(2024, 1, 15),
        "status": "Active",
        "address": "15 Green Valley Road, Ahmedabad"
    },
    {
        "roll_number": "STU-2024-003",
        "first_name": "Rohan",
        "last_name": "Verma",
        "email": "rohan.verma@university.edu",
        "phone": "+91-9876543212",
        "department": "Data Science",
        "semester": 5,
        "gpa": 3.78,
        "enrollment_date": date(2023, 8, 1),
        "status": "Active",
        "address": "78 Innovation Hub, Sector 62, Noida"
    },
    {
        "roll_number": "STU-2024-004",
        "first_name": "Ananya",
        "last_name": "Iyer",
        "email": "ananya.iyer@university.edu",
        "phone": "+91-9876543213",
        "department": "Electronics",
        "semester": 6,
        "gpa": 3.65,
        "enrollment_date": date(2023, 8, 1),
        "status": "Active",
        "address": "12 Temple Street, Mylapore, Chennai"
    },
    {
        "roll_number": "STU-2024-005",
        "first_name": "Kavya",
        "last_name": "Nair",
        "email": "kavya.nair@university.edu",
        "phone": "+91-9876543214",
        "department": "Mechanical",
        "semester": 7,
        "gpa": 3.42,
        "enrollment_date": date(2022, 8, 1),
        "status": "Active",
        "address": "89 Palm Grove Avenue, Kochi"
    },
    {
        "roll_number": "STU-2024-006",
        "first_name": "Vikram",
        "last_name": "Singh",
        "email": "vikram.singh@university.edu",
        "phone": "+91-9876543215",
        "department": "Civil",
        "semester": 8,
        "gpa": 3.55,
        "enrollment_date": date(2022, 8, 1),
        "status": "Graduated",
        "address": "23 Heritage Square, Jaipur"
    },
    {
        "roll_number": "STU-2024-007",
        "first_name": "Sneha",
        "last_name": "Reddy",
        "email": "sneha.reddy@university.edu",
        "phone": "+91-9876543216",
        "department": "Computer Science",
        "semester": 3,
        "gpa": 3.96,
        "enrollment_date": date(2024, 8, 1),
        "status": "Active",
        "address": "50 Banjara Hills, Hyderabad"
    },
    {
        "roll_number": "STU-2024-008",
        "first_name": "Dev",
        "last_name": "Chatterjee",
        "email": "dev.chatterjee@university.edu",
        "phone": "+91-9876543217",
        "department": "Data Science",
        "semester": 2,
        "gpa": 3.30,
        "enrollment_date": date(2025, 1, 10),
        "status": "Active",
        "address": "104 Lake Gardens, Kolkata"
    },
    {
        "roll_number": "STU-2024-009",
        "first_name": "Meera",
        "last_name": "Joshi",
        "email": "meera.joshi@university.edu",
        "phone": "+91-9876543218",
        "department": "Information Technology",
        "semester": 5,
        "gpa": 2.95,
        "enrollment_date": date(2023, 8, 1),
        "status": "Inactive",
        "address": "33 Deccan Gymkhana, Pune"
    },
    {
        "roll_number": "STU-2024-010",
        "first_name": "Arjun",
        "last_name": "Mehta",
        "email": "arjun.mehta@university.edu",
        "phone": "+91-9876543219",
        "department": "Electronics",
        "semester": 4,
        "gpa": 3.10,
        "enrollment_date": date(2024, 1, 15),
        "status": "Active",
        "address": "67 Marine Drive, Mumbai"
    },
    {
        "roll_number": "STU-2024-011",
        "first_name": "Ishaan",
        "last_name": "Gupta",
        "email": "ishaan.gupta@university.edu",
        "phone": "+91-9876543220",
        "department": "Computer Science",
        "semester": 8,
        "gpa": 3.88,
        "enrollment_date": date(2022, 8, 1),
        "status": "Graduated",
        "address": "18 Civil Lines, Delhi"
    },
    {
        "roll_number": "STU-2024-012",
        "first_name": "Zara",
        "last_name": "Khan",
        "email": "zara.khan@university.edu",
        "phone": "+91-9876543221",
        "department": "Mechanical",
        "semester": 3,
        "gpa": 3.15,
        "enrollment_date": date(2024, 8, 1),
        "status": "Active",
        "address": "7 Hazratganj, Lucknow"
    }
]

created_count = 0
for data in sample_students:
    obj, created = Student.objects.update_or_create(
        roll_number=data["roll_number"],
        defaults=data
    )
    if created:
        created_count += 1

print(f"Database seeded successfully! Added/Updated {len(sample_students)} student records ({created_count} new).")
