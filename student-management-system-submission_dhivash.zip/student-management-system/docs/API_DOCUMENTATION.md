# EduTrack Pro - REST API Documentation

This document specifies the complete REST API interface for the **EduTrack Pro Student Management System**, developed using Django REST Framework (DRF).

**Base URL**: `http://127.0.0.1:8000/api/`  
**Content-Type**: `application/json`  

---

## Summary of Endpoints

| Method | Endpoint | Description | Status Codes |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/students/` | List all students (paginated, searchable, filterable) | `200 OK` |
| `POST` | `/api/students/` | Create a new student record | `201 Created`, `400 Bad Request` |
| `GET` | `/api/students/{id}/` | Retrieve single student details | `200 OK`, `404 Not Found` |
| `PUT` | `/api/students/{id}/` | Full update of existing student | `200 OK`, `400 Bad Request`, `404 Not Found` |
| `PATCH` | `/api/students/{id}/` | Partial update of student fields | `200 OK`, `400 Bad Request`, `404 Not Found` |
| `DELETE` | `/api/students/{id}/` | Permanently delete student record | `204 No Content`, `404 Not Found` |
| `GET` | `/api/students/statistics/` | Aggregated dashboard KPI statistics | `200 OK` |

---

## Detailed Endpoint Specifications

### 1. List Students
`GET /api/students/`

#### Query Parameters
- `page` *(integer, optional)*: Page number for pagination (default: 1, 10 items/page).
- `search` *(string, optional)*: Search term matched against `roll_number`, `first_name`, `last_name`, `email`, and `department`.
- `department` *(string, optional)*: Filter by exact department name (e.g. `Computer Science`).
- `status` *(string, optional)*: Filter by status (`Active`, `Inactive`, `Graduated`, `Suspended`).
- `ordering` *(string, optional)*: Sort field (e.g. `gpa`, `-gpa`, `roll_number`, `created_at`).

#### Sample Response (`200 OK`)
```json
{
  "count": 12,
  "next": null,
  "previous": null,
  "results": [
    {
      "id": 1,
      "roll_number": "STU-2024-001",
      "first_name": "Aarav",
      "last_name": "Sharma",
      "full_name": "Aarav Sharma",
      "email": "aarav.sharma@university.edu",
      "phone": "+91-9876543210",
      "department": "Computer Science",
      "semester": 6,
      "gpa": "3.92",
      "enrollment_date": "2023-08-01",
      "status": "Active",
      "address": "42 Tech Boulevard, Silicon Wing, Bangalore",
      "created_at": "2026-09-17T13:39:00Z",
      "updated_at": "2026-09-17T13:39:00Z"
    }
  ]
}
```

---

### 2. Create Student
`POST /api/students/`

#### Request Body
```json
{
  "roll_number": "STU-2026-101",
  "first_name": "Divya",
  "last_name": "Sundaram",
  "email": "divya.sundaram@university.edu",
  "phone": "+91-9876501234",
  "department": "Data Science",
  "semester": 2,
  "gpa": 3.85,
  "status": "Active",
  "address": "12 Innovation Park, Bangalore"
}
```

#### Sample Response (`201 Created`)
```json
{
  "id": 13,
  "roll_number": "STU-2026-101",
  "first_name": "Divya",
  "last_name": "Sundaram",
  "full_name": "Divya Sundaram",
  "email": "divya.sundaram@university.edu",
  "phone": "+91-9876501234",
  "department": "Data Science",
  "semester": 2,
  "gpa": "3.85",
  "enrollment_date": "2026-09-17",
  "status": "Active",
  "address": "12 Innovation Park, Bangalore",
  "created_at": "2026-09-17T13:45:00Z",
  "updated_at": "2026-09-17T13:45:00Z"
}
```

---

### 3. Update Student Record
`PUT /api/students/{id}/` or `PATCH /api/students/{id}/`

- `PUT`: Replaces all fields of the record.
- `PATCH`: Modifies only the submitted fields (e.g. `{"gpa": 3.95, "status": "Graduated"}`).

---

### 4. Delete Student Record
`DELETE /api/students/{id}/`

- Response: `204 No Content`

---

### 5. Statistics Analytics Endpoint
`GET /api/students/statistics/`

#### Sample Response (`200 OK`)
```json
{
  "total_students": 12,
  "active_students": 9,
  "graduated_students": 2,
  "inactive_students": 1,
  "suspended_students": 0,
  "average_gpa": 3.56,
  "honor_roll_students": 8,
  "departments": [
    { "department": "Computer Science", "count": 3 },
    { "department": "Data Science", "count": 2 },
    { "department": "Information Technology", "count": 2 },
    { "department": "Electronics", "count": 2 },
    { "department": "Mechanical", "count": 2 },
    { "department": "Civil", "count": 1 }
  ]
}
```
