# Comprehensive Project Report
## Complete CRUD-Based Web Application Development
### Project Title: EduTrack Pro - Student Management System
**Technologies:** HTML5, CSS3, Tailwind CSS, JavaScript (ES6+), React 18, Python 3.12, Django 6.1, Django REST Framework, SQLite3

---

## 1. Executive Summary & Purpose
This project implements a complete, enterprise-grade, full-stack CRUD (Create, Read, Update, Delete) web application developed in accordance with the **Standard Operating Procedure (SOP) for CRUD-Based Web Application Development**. 

The system, titled **EduTrack Pro**, solves the operational challenges of modern academic record management by delivering a centralized, responsive, and robust web platform for managing student enrollments, academic performance (GPA), departmental allocations, and status tracking.

---

## 2. Problem Statement
Educational institutions often struggle with fragmented student records maintained in manual spreadsheets or antiquated desktop software. These outdated systems suffer from:
- Data redundancy and duplicate roll numbers or email collisions.
- Lack of centralized validation on academic metrics (e.g., invalid GPA values or missing mandatory records).
- Absence of real-time search, department filtering, and visual analytics.
- Difficulties in cross-platform access across modern mobile and desktop devices.

**EduTrack Pro** resolves these issues by implementing a secure, validated, and normalized REST-driven architecture with responsive client interfaces.

---

## 3. Project Objectives
1. Design and deploy a normalized relational database schema with constraints (primary keys, unique indices, range checks).
2. Build a high-performance RESTful API adhering to HTTP conventions (`GET`, `POST`, `PUT`, `PATCH`, `DELETE`).
3. Implement rigorous dual-layer input validation on both the client (instant UI feedback) and server (unbypassable DRF serializers).
4. Provide both an interactive React single-page interface and a standalone unified Django portal.
5. Create an automated test suite achieving 100% pass rate across all operational and edge-case scenarios.
6. Provide comprehensive documentation, ER diagrams, Postman collections, and Viva Voce preparation materials.

---

## 4. Technology Stack Specification

| Layer | Technology | Version | Purpose |
| :--- | :--- | :--- | :--- |
| **Backend Framework** | Django | 6.1.1 | High-level Python Web Framework & ORM |
| **REST API Engine** | Django REST Framework | 3.18.1 | REST API serialization, viewsets, and filters |
| **CORS Middleware** | `django-cors-headers` | 4.9.0 | Cross-Origin Resource Sharing handling |
| **Programming Language**| Python | 3.12.10 | Core backend language |
| **Frontend Framework** | React | 18.3.1 | Component-driven reactive UI |
| **Build Tool** | Vite | 6.1.0 | Fast frontend bundler and dev server |
| **Styling** | Tailwind CSS | 3.4.17 | Utility-first responsive design |
| **Database** | SQLite3 | 3.x | Zero-config ACID relational persistence |
| **Testing** | Django TestCase & Pytest | Built-in | Automated test execution |
| **API Client Testing** | Postman | v2.1 | REST API verification collection |
| **Version Control** | Git | 2.55 | Source code version management |

---

## 5. CRUD Implementation Walkthrough

### 1. Create Operation
- User inputs student details in the "Add Student" modal.
- Client validation verifies non-empty fields, valid email structure, numeric GPA within 0.00-4.00.
- `POST /api/students/` sends JSON payload.
- `StudentSerializer` checks uniqueness against existing database records.
- Django ORM saves record; API returns `201 Created`. UI displays success toast and updates the table.

### 2. Read Operation
- `GET /api/students/?page=1&department=...&search=...` retrieves paginated records.
- `GET /api/students/{id}/` retrieves individual record for the "Details" drawer.
- `GET /api/students/statistics/` dynamically recalculates aggregate metrics (average GPA, active counts, department distributions).

### 3. Update Operation
- Clicking "Edit" fetches student details and pre-populates all form controls.
- `PUT /api/students/{id}/` validates and updates all record fields.
- `PATCH /api/students/{id}/` permits updating isolated attributes (such as GPA after examination results).
- Server returns `200 OK` and interface refreshes instantaneously.

### 4. Delete Operation
- Clicking "Delete" opens a modal dialog displaying the student's name and roll number.
- Sending `DELETE /api/students/{id}/` removes the record.
- Server returns `204 No Content`, table updates, and a green notification alert confirms removal.

---

## 6. Testing & Quality Assurance

Automated tests are implemented in `students/tests.py`. Test coverage includes 17 tests:
- Create student success (201)
- Duplicate roll number rejection (400)
- Duplicate email rejection (400)
- Invalid email format rejection (400)
- Out of range GPA rejection (400)
- Out of range semester rejection (400)
- Missing mandatory fields (400)
- List students paginated (200)
- Retrieve student success (200)
- Retrieve non-existent student (404)
- Full update PUT (200)
- Partial update PATCH (200)
- Delete student success (204)
- Delete non-existent student (404)
- Search filter by keyword (200)
- Department filter (200)
- Aggregate statistics calculation (200)

**Execution Result:**
```
Ran 17 tests in 0.110s
OK (17 passed, 0 failed, 0 errors)
```
