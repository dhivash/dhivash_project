# Database Schema & Entity-Relationship Model

## Relational Architecture

The application utilizes a normalized relational schema deployed on **SQLite3**, managed through **Django Object-Relational Mapping (ORM)** migrations.

---

## Entity: `students_student` Table Definition

```sql
CREATE TABLE "students_student" (
    "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
    "roll_number" varchar(20) NOT NULL UNIQUE,
    "first_name" varchar(50) NOT NULL,
    "last_name" varchar(50) NOT NULL,
    "email" varchar(100) NOT NULL UNIQUE,
    "phone" varchar(20) NOT NULL,
    "department" varchar(50) NOT NULL,
    "semester" integer NOT NULL CHECK ("semester" BETWEEN 1 AND 8),
    "gpa" decimal(3, 2) NOT NULL CHECK ("gpa" BETWEEN 0.00 AND 4.00),
    "enrollment_date" date NOT NULL,
    "status" varchar(20) NOT NULL,
    "address" text NOT NULL,
    "created_at" datetime NOT NULL,
    "updated_at" datetime NOT NULL
);

-- Indices for performance optimization
CREATE INDEX "students_student_roll_number_idx" ON "students_student" ("roll_number");
CREATE INDEX "students_student_email_idx" ON "students_student" ("email");
CREATE INDEX "students_student_created_at_idx" ON "students_student" ("created_at" DESC);
```

---

## Field Dictionary

| Column Name | SQLite Data Type | Constraints | Default | Business Purpose |
| :--- | :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Auto | Surrogate unique identifier |
| `roll_number` | VARCHAR(20) | NOT NULL, UNIQUE, INDEXED | None | Academic registration identifier |
| `first_name` | VARCHAR(50) | NOT NULL | None | Given name of student |
| `last_name` | VARCHAR(50) | NOT NULL | None | Family/Surname of student |
| `email` | VARCHAR(100) | NOT NULL, UNIQUE, INDEXED | None | Institutional email communication |
| `phone` | VARCHAR(20) | NOT NULL | None | Contact telephone number |
| `department` | VARCHAR(50) | NOT NULL | 'Computer Science' | Academic discipline division |
| `semester` | INTEGER | NOT NULL, Range 1 to 8 | 1 | Current active semester |
| `gpa` | DECIMAL(3, 2)| NOT NULL, Range 0.00 to 4.00 | 3.50 | Cumulative Grade Point Average |
| `enrollment_date`| DATE | NOT NULL | `localdate()` | Initial matriculation date |
| `status` | VARCHAR(20) | NOT NULL | 'Active' | Lifecycle status (`Active`, `Inactive`, etc.) |
| `address` | TEXT | NOT NULL | '' | Residential/mailing location |
| `created_at` | DATETIME | NOT NULL | `auto_now_add=True`| Audit creation timestamp |
| `updated_at` | DATETIME | NOT NULL | `auto_now=True` | Audit last modified timestamp |
