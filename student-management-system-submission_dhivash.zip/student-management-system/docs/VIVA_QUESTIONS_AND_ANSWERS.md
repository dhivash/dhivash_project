# EduTrack Pro - Viva Voce Preparation Guide (25+ Questions & Answers)

This guide provides students with thorough, authoritative answers to questions frequently asked by professors, internal examiners, and external evaluators during project defense.

---

### Q1. What is the architecture of your web application?
**Answer:**  
Our project implements a **3-tier decoupled client-server architecture**:
1. **Presentation Layer (Frontend)**: Developed using modern JavaScript/React and Tailwind CSS. It communicates with the backend asynchronously using standard HTTP/JSON requests (Fetch API / Axios).
2. **Application / Business Logic Layer (Backend)**: Developed using Python 3.12, Django 6.1, and Django REST Framework (DRF). It manages URL routing, request dispatching, input validation, serialization/deserialization, and business logic.
3. **Data Layer (Database)**: An SQLite relational database managed via Django's Object-Relational Mapper (ORM), ensuring ACID compliance, parameter-binding against SQL injection, and database independence.

---

### Q2. What does CRUD stand for, and how is each operation implemented in your system?
**Answer:**  
CRUD represents the four fundamental operations of persistent storage:
- **Create**: HTTP `POST /api/students/` receives a JSON payload, deserializes and validates it in `StudentSerializer`, and saves it to the database, returning HTTP `201 Created`.
- **Read**: HTTP `GET /api/students/` retrieves paginated records with optional search and filters. `GET /api/students/{id}/` fetches an individual student's details, returning HTTP `200 OK`.
- **Update**: HTTP `PUT /api/students/{id}/` performs full record updates; `PATCH /api/students/{id}/` updates selected fields (e.g. GPA or status). Both return HTTP `200 OK`.
- **Delete**: HTTP `DELETE /api/students/{id}/` deletes the record from the database and returns HTTP `204 No Content`.

---

### Q3. Why did you choose Django REST Framework instead of standard Django views?
**Answer:**  
Standard Django views render HTML templates server-side (tightly coupled monolith). Django REST Framework (DRF) allows us to:
- Build a **pure RESTful API** that outputs clean, standardized JSON data.
- Decouple the frontend from the backend, enabling web, mobile apps, or third-party services to consume the same endpoints.
- Leverage DRF's serializers for robust input validation, data coercion, and nested field representations.
- Utilize built-in pagination, search filters, and the interactive Browsable API for rapid testing.

---

### Q4. How do you prevent SQL Injection in your project?
**Answer:**  
We avoid raw SQL string concatenations entirely. We utilize **Django's Object-Relational Mapping (ORM)** (e.g., `Student.objects.filter(...)`). Under the hood, Django ORM converts query parameters into parameterized SQL statements where inputs are safely escaped and bound separately from the SQL query structure by the database driver.

---

### Q5. What is CORS and why did you configure `django-cors-headers`?
**Answer:**  
**CORS** (Cross-Origin Resource Sharing) is a browser security mechanism that restricts web applications from making HTTP requests to a domain, port, or protocol different from the one serving the frontend. Because React often runs on `http://localhost:3000` while Django runs on `http://127.0.0.1:8000`, the browser would block the requests unless the Django server sends the `Access-Control-Allow-Origin` HTTP headers. We installed `django-cors-headers` and configured `CorsMiddleware` to permit seamless cross-origin requests.

---

### Q6. What is the difference between `PUT` and `PATCH` methods?
**Answer:**  
- **PUT**: Replaces the entire resource. The client must supply all required fields of the object. Omitted fields may be reset or cause validation errors.
- **PATCH**: Performs a partial update. The client only sends the specific attributes they wish to alter (e.g., updating only `gpa` or `status`), leaving all other fields unchanged.

---

### Q7. How is validation handled on the client vs. server side?
**Answer:**  
- **Client-Side Validation** (in JavaScript/React): Checks for empty fields, email regex, and numeric ranges immediately on form submission before network transmission. This provides instantaneous visual feedback to the user.
- **Server-Side Validation** (in DRF `StudentSerializer`): Validates incoming data against business rules (e.g., unique roll numbers across the database, valid GPA range between 0.00 and 4.00, phone length). Server-side validation is mandatory because client-side checks can be bypassed via direct API calls (e.g. through Postman or curl).

---

### Q8. What HTTP status codes does your API return?
**Answer:**  
- `200 OK`: Successful GET, PUT, or PATCH operation.
- `201 Created`: Successful POST operation (record created).
- `204 No Content`: Successful DELETE operation.
- `400 Bad Request`: Validation failure (e.g. duplicate email, invalid GPA).
- `404 Not Found`: Requested student ID does not exist in the database.
- `500 Internal Server Error`: Unhandled server exception.

---

### Q9. What are Django Migrations?
**Answer:**  
Migrations are Django’s mechanism for propagating changes made to Python models into the database schema.
- `makemigrations`: Inspects `models.py` and creates migration instruction files (e.g., `0001_initial.py`).
- `migrate`: Executes the schema changes against the database engine (`db.sqlite3`).

---

### Q10. How does the dashboard statistics endpoint work?
**Answer:**  
The `@action(detail=False, methods=['get']) def statistics(self, request)` endpoint aggregates database values directly using Django ORM functions `Avg('gpa')`, `Count('id')`, and `.values('department').annotate(count=Count('id'))`. This delivers lightning-fast analytics in a single SQL query without loading all records into memory.

---

### Q11. How did you test your application?
**Answer:**  
Testing was conducted on three levels:
1. **Automated Unit & Integration Tests**: 17 tests written using Django's `TestCase` and DRF's `APIClient`, testing all CRUD endpoints, duplicate checks, boundary validation, and 404 handlers.
2. **API Endpoint Testing**: Postman Collection v2.1 with pre-configured assertions and test scripts.
3. **Frontend & Manual Verification**: Tested responsive desktop/mobile viewports, form validation error triggers, and live modal interactions.
