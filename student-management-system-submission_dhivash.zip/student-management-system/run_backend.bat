@echo off
title EduTrack Pro - Backend Server
set "PATH=C:\Users\ASus\AppData\Local\Programs\Python\Python312;C:\Users\ASus\AppData\Local\Programs\Python\Python312\Scripts;%PATH%"
cd /d %~dp0backend
echo Starting Django Backend Server on http://127.0.0.1:8000...
python manage.py runserver 127.0.0.1:8000
pause
