# EduTrack Pro - Complete CRUD Student Management System

[![Python](https://img.shields.io/badge/Python-3.12-blue.svg)](https://www.python.org/)
[![Django](https://img.shields.io/badge/Django-6.1-green.svg)](https://www.djangoproject.com/)
[![DRF](https://img.shields.io/badge/Django%20REST-3.18-red.svg)](https://www.django-rest-framework.org/)
[![React](https://img.shields.io/badge/React-18-61dafb.svg)](https://react.dev/)
[![SQLite](https://img.shields.io/badge/Database-SQLite3-lightgrey.svg)](https://www.sqlite.org/)

> **Full-Stack CRUD Web Application Development**  
> Developed in strict accordance with the **Standard Operating Procedure (SOP) for CRUD-Based Web Application Development**.

---

## Quick Start (Single Click)

Double-click `start_all.bat` in this directory to:
1. Start the Django REST Framework backend server (`http://127.0.0.1:8000`).
2. Automatically launch your default web browser to the live interactive application.

Alternatively, execute via PowerShell or Command Prompt:
```bash
# Start Backend
run_backend.bat

# Run Automated Test Suite (17 Tests)
run_tests.bat

# Run Standalone React Frontend (Optional Vite Dev Server)
run_frontend.bat
```

---

## Key Features & CRUD Operations

- **Create (POST `/api/students/`)**: Register new students with real-time validation (email regex, uniqueness checks for roll number and email, GPA range 0.00-4.00, semester 1-8).
- **Read (GET `/api/students/`)**: Paginated records, full-text search across names, roll numbers, and emails; filtering by academic department and enrollment status.
- **Update (PUT / PATCH `/api/students/{id}/`)**: Full or partial record modification with instant interface synchronization.
- **Delete (DELETE `/api/students/{id}/`)**: Safe deletion with modal confirmation preventing accidental data loss.
- **Analytics & Statistics (GET `/api/students/statistics/`)**: Live metric cards showing Total Enrolled, Active Students, Average GPA, and Honor Roll counts.
- **Multi-View Interface**: Seamless toggle between detailed Data Table View and modern Grid Card View.

---

## Directory Architecture

```
student-management-system/
├── backend/                  # Django & Django REST Framework application
│   ├── edutrack/             # Project settings, routing & WSGI/ASGI
│   ├── students/             # Core app: models, serializers, views, urls, tests
│   │   ├── migrations/       # Database migrations
│   │   ├── models.py         # Student entity schema
│   │   ├── serializers.py    # DRF data serialization & validation
│   │   ├── views.py          # ViewSets & statistical endpoints
│   │   ├── urls.py           # REST routing
│   │   └── tests.py          # 17 Automated unit & integration tests
│   ├── templates/            # Unified modern SPA dashboard (index.html)
│   ├── db.sqlite3            # Pre-seeded SQLite database
│   ├── seed_data.py          # Realistic database seeder
│   └── requirements.txt      # Python dependencies
├── frontend/                 # Standalone React 18 + Vite SPA
│   ├── src/
│   │   ├── App.jsx           # Main React component
│   │   ├── services/api.js   # Axios API client
│   │   └── index.css         # Tailwind styles
│   ├── package.json          # Node dependencies
│   └── vite.config.js        # Vite build configuration
├── postman/                  # API testing artifacts
│   └── Student_Management_API.postman_collection.json
├── tests/                    # Automated testing execution logs
│   └── test_results.txt      # 17/17 tests passing verification log
├── docs/                     # Comprehensive SOP documentation
│   ├── PROJECT_REPORT.md     # Complete project documentation report
│   ├── PROJECT_REPORT.html   # Printable styled documentation
│   ├── API_DOCUMENTATION.md  # Detailed REST API specification
│   ├── DATABASE_SCHEMA.md    # ER diagram and schema constraints
│   └── VIVA_QUESTIONS_AND_ANSWERS.md # 25+ Viva prep questions & answers
├── start_all.bat             # 1-Click launcher
├── run_backend.bat           # Backend launcher
├── run_frontend.bat          # React frontend launcher
├── run_tests.bat             # Automated test runner
└── README.md                 # Project guide
```

---

## Evaluation Checklist (SOP Section 17)

| Requirement | Status | Details |
| :--- | :---: | :--- |
| Application starts without errors | Yes | Tested with `python manage.py runserver` |
| Database connection works | Yes | SQLite initialized with complete schema migrations |
| Create operation works | Yes | Modal form with client & server validation |
| Read/list operation works | Yes | Paginated table & card layout with search & filters |
| Update operation works | Yes | Pre-populated modal supporting PUT & PATCH |
| Delete operation works | Yes | Confirmation modal with record removal |
| Server & Client Validation | Yes | Unique roll number/email, GPA 0.00-4.00, phone format |
| Automated Tests Passing | Yes | 17/17 tests passing (`test_results.txt`) |
| Postman Collection Included | Yes | Postman v2.1 collection with tests included |
| Complete Documentation & Viva Guide | Yes | Word/PDF-ready reports and 25+ viva answers |

---

Developed for Academic Project Submission &bull; EduTrack Pro
