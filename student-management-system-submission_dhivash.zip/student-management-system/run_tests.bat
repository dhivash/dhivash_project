@echo off
title EduTrack Pro - Automated Test Suite
set "PATH=C:\Users\ASus\AppData\Local\Programs\Python\Python312;C:\Users\ASus\AppData\Local\Programs\Python\Python312\Scripts;%PATH%"
cd /d %~dp0backend
echo Running Automated CRUD & API Tests...
python manage.py test students --verbosity 2
echo.
pause
