import React, { useState, useEffect, useCallback } from 'react';
import { studentApi } from './services/api';

export default function App() {
  const [students, setStudents] = useState([]);
  const [stats, setStats] = useState({ total_students: 0, active_students: 0, average_gpa: 0, honor_roll_students: 0 });
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [department, setDepartment] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [currentPage, setCurrentPage] = useState(1);
  const [pagination, setPagination] = useState({ count: 0, next: null, previous: null });
  const [viewMode, setViewMode] = useState('table'); // 'table' or 'cards'

  // Modals state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('create'); // 'create' or 'edit'
  const [currentStudent, setCurrentStudent] = useState(null);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [studentToDelete, setStudentToDelete] = useState(null);

  // Toast
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page: currentPage };
      if (search.trim()) params.search = search.trim();
      if (department !== 'All') params.department = department;
      if (statusFilter !== 'All') params.status = statusFilter;

      const [resStudents, resStats] = await Promise.all([
        studentApi.getAll(params),
        studentApi.getStatistics()
      ]);

      setStudents(resStudents.data.results || resStudents.data);
      setPagination({
        count: resStudents.data.count || 0,
        next: resStudents.data.next,
        previous: resStudents.data.previous
      });
      setStats(resStats.data);
    } catch (err) {
      showToast('Error connecting to API server: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  }, [currentPage, search, department, statusFilter]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Form submission handler
  const handleFormSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const payload = {
      roll_number: formData.get('roll_number').toUpperCase(),
      first_name: formData.get('first_name'),
      last_name: formData.get('last_name'),
      email: formData.get('email').toLowerCase(),
      phone: formData.get('phone'),
      department: formData.get('department'),
      semester: parseInt(formData.get('semester'), 10),
      gpa: parseFloat(formData.get('gpa')),
      status: formData.get('status'),
      address: formData.get('address') || ''
    };

    try {
      if (modalMode === 'edit' && currentStudent) {
        await studentApi.update(currentStudent.id, payload);
        showToast('Student record updated successfully!', 'success');
      } else {
        await studentApi.create(payload);
        showToast('New student registered successfully!', 'success');
      }
      setIsModalOpen(false);
      loadData();
    } catch (err) {
      const msg = err.response?.data ? JSON.stringify(err.response.data) : err.message;
      showToast('Validation Error: ' + msg, 'error');
    }
  };

  const handleDeleteConfirm = async () => {
    if (!studentToDelete) return;
    try {
      await studentApi.delete(studentToDelete.id);
      showToast('Student removed successfully!', 'success');
      setIsDeleteOpen(false);
      loadData();
    } catch (err) {
      showToast('Failed to delete: ' + err.message, 'error');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800">
      {/* TOP NAVBAR */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 font-bold text-xl">
              E
            </div>
            <div>
              <span className="font-bold text-lg text-slate-900 tracking-tight">EduTrack <span className="text-indigo-600">Pro</span></span>
              <span className="hidden sm:inline-block ml-2 text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">React + Django REST</span>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={() => { setCurrentStudent(null); setModalMode('create'); setIsModalOpen(true); }}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-sm font-semibold rounded-lg shadow-sm transition-all"
            >
              + Add Student
            </button>
          </div>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {/* KPI STATS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Enrolled</p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">{stats.total_students}</h3>
              <p className="text-xs text-slate-400 mt-1">Student database count</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl font-bold">#</div>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Status</p>
              <h3 className="text-2xl font-bold text-emerald-600 mt-1">{stats.active_students}</h3>
              <p className="text-xs text-slate-400 mt-1">In good standing</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl font-bold">&radic;</div>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Average GPA</p>
              <h3 className="text-2xl font-bold text-indigo-600 mt-1">{parseFloat(stats.average_gpa || 0).toFixed(2)}</h3>
              <p className="text-xs text-slate-400 mt-1">Scale of 4.00</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl font-bold">&star;</div>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Honor Roll</p>
              <h3 className="text-2xl font-bold text-amber-600 mt-1">{stats.honor_roll_students}</h3>
              <p className="text-xs text-slate-400 mt-1">GPA &ge; 3.50</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xl font-bold">&hearts;</div>
          </div>
        </div>

        {/* TOOLBAR */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-4 items-center justify-between">
          <input
            type="text"
            placeholder="Search by name, roll number, or email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full md:w-96 text-sm bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
          />

          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-end">
            <select
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2"
            >
              <option value="All">All Departments</option>
              <option value="Computer Science">Computer Science</option>
              <option value="Information Technology">Information Technology</option>
              <option value="Electronics">Electronics</option>
              <option value="Mechanical">Mechanical</option>
              <option value="Civil">Civil</option>
              <option value="Data Science">Data Science</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2"
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Graduated">Graduated</option>
              <option value="Suspended">Suspended</option>
            </select>

            <button
              onClick={() => loadData()}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-700"
            >
              Refresh
            </button>
          </div>
        </div>

        {/* DATA TABLE */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr class="bg-slate-50/80 border-b border-slate-200 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-3.5 px-4">Student</th>
                <th className="py-3.5 px-4">Roll Number</th>
                <th className="py-3.5 px-4">Department</th>
                <th className="py-3.5 px-4 text-center">Semester</th>
                <th className="py-3.5 px-4 text-center">GPA</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {students.map((st) => (
                <tr key={st.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4 flex items-center space-x-3">
                    <div className="w-9 h-9 rounded-xl bg-indigo-100 text-indigo-700 font-bold text-xs flex items-center justify-center flex-shrink-0">
                      {(st.first_name[0] || '') + (st.last_name[0] || '')}
                    </div>
                    <div>
                      <div className="font-semibold text-slate-800">{st.first_name} {st.last_name}</div>
                      <div className="text-xs text-slate-400 font-mono">{st.email}</div>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono text-xs font-semibold text-slate-700">{st.roll_number}</td>
                  <td className="py-3 px-4">
                    <span className="px-2.5 py-1 text-xs font-medium rounded-lg bg-slate-100 text-slate-700 border border-slate-200">
                      {st.department}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center font-medium text-slate-700">Sem {st.semester}</td>
                  <td className="py-3 px-4 text-center">
                    <span className={`px-2 py-0.5 text-xs font-bold rounded-full ${parseFloat(st.gpa) >= 3.5 ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'}`}>
                      {parseFloat(st.gpa).toFixed(2)}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${st.status === 'Active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600'}`}>
                      {st.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right space-x-2 whitespace-nowrap">
                    <button
                      onClick={() => { setCurrentStudent(st); setIsViewOpen(true); }}
                      className="px-2 py-1 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md"
                    >
                      View
                    </button>
                    <button
                      onClick={() => { setCurrentStudent(st); setModalMode('edit'); setIsModalOpen(true); }}
                      className="px-2 py-1 text-xs font-semibold text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-md"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => { setStudentToDelete(st); setIsDeleteOpen(true); }}
                      className="px-2 py-1 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-md"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>

      {/* CREATE / EDIT MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl my-8">
            <h3 className="text-lg font-bold text-slate-900 mb-4">
              {modalMode === 'edit' ? 'Edit Student Record' : 'Add New Student Record'}
            </h3>
            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Roll Number *</label>
                  <input
                    type="text"
                    name="roll_number"
                    defaultValue={currentStudent?.roll_number || ''}
                    required
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 uppercase"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Department *</label>
                  <select
                    name="department"
                    defaultValue={currentStudent?.department || 'Computer Science'}
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2"
                  >
                    <option value="Computer Science">Computer Science</option>
                    <option value="Information Technology">Information Technology</option>
                    <option value="Electronics">Electronics</option>
                    <option value="Mechanical">Mechanical</option>
                    <option value="Civil">Civil</option>
                    <option value="Data Science">Data Science</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">First Name *</label>
                  <input
                    type="text"
                    name="first_name"
                    defaultValue={currentStudent?.first_name || ''}
                    required
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Last Name *</label>
                  <input
                    type="text"
                    name="last_name"
                    defaultValue={currentStudent?.last_name || ''}
                    required
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Email *</label>
                  <input
                    type="email"
                    name="email"
                    defaultValue={currentStudent?.email || ''}
                    required
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Phone *</label>
                  <input
                    type="text"
                    name="phone"
                    defaultValue={currentStudent?.phone || ''}
                    required
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Semester (1-8) *</label>
                  <input
                    type="number"
                    name="semester"
                    min="1"
                    max="8"
                    defaultValue={currentStudent?.semester || 1}
                    required
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">GPA (0.0 - 4.0) *</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="4"
                    name="gpa"
                    defaultValue={currentStudent?.gpa || 3.50}
                    required
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Status *</label>
                  <select
                    name="status"
                    defaultValue={currentStudent?.status || 'Active'}
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="Graduated">Graduated</option>
                    <option value="Suspended">Suspended</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Address</label>
                <textarea
                  name="address"
                  rows="2"
                  defaultValue={currentStudent?.address || ''}
                  className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2"
                ></textarea>
              </div>

              <div className="pt-4 flex justify-end space-x-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg"
                >
                  Save Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* VIEW MODAL */}
      {isViewOpen && currentStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 mb-2">{currentStudent.first_name} {currentStudent.last_name}</h3>
            <p className="text-xs font-mono text-slate-400 mb-4">{currentStudent.roll_number}</p>
            <div className="bg-slate-50 p-4 rounded-xl text-sm space-y-2">
              <div><strong>Department:</strong> {currentStudent.department}</div>
              <div><strong>Semester:</strong> Sem {currentStudent.semester}</div>
              <div><strong>GPA:</strong> {parseFloat(currentStudent.gpa).toFixed(2)} / 4.00</div>
              <div><strong>Email:</strong> {currentStudent.email}</div>
              <div><strong>Phone:</strong> {currentStudent.phone}</div>
              <div><strong>Status:</strong> {currentStudent.status}</div>
              <div><strong>Address:</strong> {currentStudent.address || 'N/A'}</div>
            </div>
            <div className="mt-4 flex justify-end">
              <button
                onClick={() => setIsViewOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE MODAL */}
      {isDeleteOpen && studentToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl text-center">
            <h3 className="text-base font-bold text-slate-900">Delete Record</h3>
            <p className="text-xs text-slate-500 mt-2">
              Are you sure you want to remove <strong>{studentToDelete.first_name} {studentToDelete.last_name}</strong>?
            </p>
            <div className="mt-6 flex justify-center space-x-3">
              <button
                onClick={() => setIsDeleteOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteConfirm}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                Delete Record
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TOAST ALERT */}
      {toast && (
        <div className={`fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl shadow-lg text-sm text-white font-medium ${toast.type === 'error' ? 'bg-rose-900' : 'bg-emerald-900'}`}>
          {toast.message}
        </div>
      )}

      {/* FOOTER */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-4 text-center text-xs text-slate-400">
        EduTrack Pro &bull; Complete CRUD-Based Web Application Development SOP &bull; Django REST &bull; React
      </footer>
    </div>
  );
}
