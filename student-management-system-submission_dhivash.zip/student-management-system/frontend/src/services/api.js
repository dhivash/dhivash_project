import axios from 'axios';

const API_BASE_URL = 'http://127.0.0.1:8000/api/students/';

export const studentApi = {
  getAll: (params = {}) => axios.get(API_BASE_URL, { params }),
  getById: (id) => axios.get(`${API_BASE_URL}${id}/`),
  create: (data) => axios.post(API_BASE_URL, data),
  update: (id, data) => axios.put(`${API_BASE_URL}${id}/`, data),
  patch: (id, data) => axios.patch(`${API_BASE_URL}${id}/`, data),
  delete: (id) => axios.delete(`${API_BASE_URL}${id}/`),
  getStatistics: () => axios.get(`${API_BASE_URL}statistics/`),
};
